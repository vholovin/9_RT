#include "rtv.h"

t_vec3d		ft_set_vector(float x, float y, float z)
{
	t_vec3d tmp;

	tmp.x = x;
	tmp.y = y;
	tmp.z = z;
	return (tmp);
}