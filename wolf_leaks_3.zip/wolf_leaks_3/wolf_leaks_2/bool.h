#ifndef _BOOL_H
# define _BOOL_H

/*
** Boolean replacement
*/
typedef enum		e_bool
{
	false, true
}					t_bool;

#endif
